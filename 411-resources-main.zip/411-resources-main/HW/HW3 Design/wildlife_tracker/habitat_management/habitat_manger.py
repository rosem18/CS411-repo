from typing import Optional, List

class HabitatManager:

    pass
