from typing import Optional

class MigrationPath:

    pass