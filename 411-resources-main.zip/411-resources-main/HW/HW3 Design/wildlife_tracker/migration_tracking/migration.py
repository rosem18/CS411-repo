from typing import Any

class Migration:

    pass