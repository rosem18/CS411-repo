from typing import Optional


class MigrationManager:

    pass
