from typing import Any, Optional

class Animal:

    pass
