# 411-resources

Various resources helpful / necessary for BU's CS411 Software Engineering course